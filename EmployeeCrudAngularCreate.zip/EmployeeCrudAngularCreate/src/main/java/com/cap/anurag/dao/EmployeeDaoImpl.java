package com.cap.anurag.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cap.anurag.entities.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Employee create(Employee entity) throws RecordNotFoundException {
		return entityManager.merge(entity);

	}

}
