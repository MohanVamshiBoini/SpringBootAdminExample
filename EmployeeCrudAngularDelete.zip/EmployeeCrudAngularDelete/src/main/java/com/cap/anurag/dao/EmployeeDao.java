package com.cap.anurag.dao;

import com.cap.anurag.entities.Employee;

public interface EmployeeDao {

	Employee deleteEmployeeById(Integer id);


}
